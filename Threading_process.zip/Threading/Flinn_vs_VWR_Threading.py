import csv
import queue
import re
import os
import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import ElementClickInterceptedException
from selenium.webdriver.chrome.options import Options
from bs4 import BeautifulSoup
import random
from module_package import *
from transformers import BertTokenizer, BertModel
import torch
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import nltk
from selenium.common.exceptions import ElementClickInterceptedException, TimeoutException
import logging
import glob
import concurrent.futures
from queue import Queue


# Setup logging
log_dir = r'Output/temp'
log_file = 'web_scraping_vwr.log'

# Ensure the directory exists
os.makedirs(log_dir, exist_ok=True)
log_path = os.path.join(log_dir, log_file)

logging.basicConfig(filename=log_path, level=logging.INFO, format='%(asctime)s %(message)s')


nltk.data.path.append(r'/Users/g6-media/Pictures/nltk_data')

model_name = 'bert-base-uncased'
tokenizer = BertTokenizer.from_pretrained(model_name)
model = BertModel.from_pretrained(model_name)
stop_words = set(stopwords.words('english'))

def process_flinn_product(original_flinn_row, flinn_word_set, vwr_products, threshold, driver, flinn_csv, vwr_csv):
    original_flinn_product = original_flinn_row['Flinn_product_name']
    flinn_product_id = original_flinn_row['Flinn_product_id']
    flinn_row = flinn_csv[flinn_csv['Flinn_product_id'] == flinn_product_id]
    desc_name = flinn_row.iloc[0]['Flinn_product_desc']
    key_name = original_flinn_product
    best_match = None
    best_match_score = 0

    for original_vwr_row, vwr_word_set in vwr_products:
        combined_similarity = word_similarity(flinn_word_set, vwr_word_set)
        if 0.3 <= threshold <= 0.4:
            combined_similarity = float(re.search(r'\d*\.\d*', str(combined_similarity)).group())
            if combined_similarity == threshold:
                product_ids = fetch_vwr_product_ids(driver, key_name)
                if not product_ids:
                    if combined_similarity >= best_match_score:
                        best_match_score = combined_similarity
                        best_match = original_vwr_row
                    continue
                for product_id in product_ids:
                    vwr_row = vwr_csv[vwr_csv['VWR_product_id'] == product_id]
                    if not vwr_row.empty:
                        vwr_title = vwr_row.iloc[0]['VWR_product_name']
                        vwr_description = vwr_row.iloc[0]['VWR_product_desc']
                        title_similarity_score = calculate_similarity(key_name, vwr_title, pooling_strategy='mean')
                        description_similarity_score = calculate_similarity(desc_name, vwr_description, pooling_strategy='mean')
                        combined_similarity_score = (title_similarity_score + description_similarity_score) / 2

                        if combined_similarity_score >= best_match_score:
                            best_match_score = combined_similarity_score
                            best_match = original_vwr_row
                break
        else:
            if combined_similarity >= best_match_score:
                best_match_score = combined_similarity
                best_match = original_vwr_row

    return original_flinn_row, best_match, best_match_score


def remove_stop_words(sentence):
    if isinstance(sentence, float):
        return ''
    words = word_tokenize(sentence.lower())
    filtered_words = [word for word in words if word not in stop_words]
    filtered_sentence = ' '.join(filtered_words)
    return filtered_sentence


def get_sentence_embedding(sentence, pooling_strategy='mean'):
    filtered_sentence = remove_stop_words(sentence)
    inputs = tokenizer(filtered_sentence, return_tensors='pt', truncation=True, padding=True, max_length=128)
    input_ids = inputs['input_ids']
    attention_mask = inputs['attention_mask']

    with torch.no_grad():
        outputs = model(input_ids, attention_mask=attention_mask)

    last_hidden_state = outputs.last_hidden_state

    if pooling_strategy == 'mean':
        sentence_embedding = torch.mean(last_hidden_state, dim=1)
    elif pooling_strategy == 'cls':
        sentence_embedding = last_hidden_state[:, 0, :]
    elif pooling_strategy == 'max':
        sentence_embedding = torch.max(last_hidden_state, dim=1)[0]
    else:
        raise ValueError(f"Unknown pooling strategy: {pooling_strategy}")

    sentence_embedding = torch.nn.functional.normalize(sentence_embedding, p=2, dim=1)
    return sentence_embedding


def calculate_similarity(sentence1, sentence2, pooling_strategy='max'):
    embedding1 = get_sentence_embedding(sentence1, pooling_strategy)
    embedding2 = get_sentence_embedding(sentence2, pooling_strategy)
    similarity = cosine_similarity(embedding1.numpy(), embedding2.numpy())
    return similarity[0][0]

# List of common color names
color_names = ['red', 'green', 'blue', 'yellow', 'orange', 'purple', 'pink', 'brown', 'black', 'white', 'gray', 'silver']


def clean_text(text):
    # Remove colors
    for color in color_names:
        text = re.sub(rf'\b{color}\b', '', text, flags=re.IGNORECASE)
    # Remove ml and mm values
    text = re.sub(r'\b\d+(\.\d+)?\s*(mL|mm)\b', '', text, flags=re.IGNORECASE)
    # Remove standalone numbers
    text = re.sub(r'\b\d+\b', '', text)
    return text.strip()

# Function to get word sets from product names
def get_word_set(text):
    # Split the text into words, remove any empty words
    return set(word for word in re.split(r'\W+', text) if word)

# Function to get the word similarity ratio between two sets of words
def word_similarity(set1, set2):
    return len(set1 & set2) / len(set1 | set2)


# def read_threshold_log():
#     file_path = os.path.join('Output', 'temp', 'vwr_threshold_log.txt')
#     completed_thresholds = set()
#     if os.path.exists(file_path):
#         with open(file_path, 'r') as file:
#             for line in file:
#                 completed_thresholds.add(line.strip())
#     return completed_thresholds
#
#
# def write_threshold_log(threshold):
#     output_dir = os.path.join('Output', 'temp')
#     if not os.path.exists(output_dir):
#         os.makedirs(output_dir)
#     file_path = os.path.join(output_dir, 'vwr_threshold_log.txt')
#     with open(file_path, 'a', encoding='utf-8') as file:
#         file.write(f"{threshold}\n")
#
# def read_global_matched_products():
#     try:
#         with open('Output/temp/global_matched_vwr_products.txt', 'r') as file:
#             global_matched_products = set(file.read().splitlines())
#         return global_matched_products
#     except FileNotFoundError:
#         return set()
#
# def write_global_matched_products(matched_products):
#     output_dir = os.path.join('Output', 'temp')
#     if not os.path.exists(output_dir):
#         os.makedirs(output_dir)
#     file_path = os.path.join(output_dir, 'global_matched_vwr_products.txt')
#     with open(file_path, 'w') as file:
#         for product_id in matched_products:
#             file.write(f"{product_id}\n")


def fetch_vwr_product_ids(driver, key_name):
    try:
        driver.get('https://us.vwr.com/store/')
        search_element = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.NAME, 'keyword'))
        )
        search_element.send_keys(key_name)

        search_button = WebDriverWait(driver, 30).until(
            EC.presence_of_element_located((By.XPATH, "//button[@aria-label='Submit search query']"))
        )

        try:
            driver.execute_script("arguments[0].scrollIntoView(true);", search_button)
            WebDriverWait(driver, 30).until(EC.element_to_be_clickable((By.XPATH, "//button[@aria-label='Submit search query']")))
            search_button.click()
        except ElementClickInterceptedException:
            driver.execute_script("arguments[0].click();", search_button)

        time.sleep(random.randint(1, 20))  # Randomized wait time between 1 and 20 seconds
        soup = BeautifulSoup(driver.page_source, 'html.parser')
        results_number = soup.find_all('div',  class_='col-sm-8')
        product_ids = [single_number.find('div', class_='search-item__info').text.split(': ', 1)[-1].strip() for single_number in results_number]
        return product_ids
    except TimeoutException as e:
        logging.error(f"TimeoutException: {e}")
        driver.save_screenshot('timeout_exception_screenshot.png')
    except Exception as e:
        logging.error(f"An error occurred: {e}")


def match_products(flinn_products, vwr_products, initial_threshold, threshold_decrement, output_folder, batch_size=100, num_threads=4):
    start_time = time.time()
    total_comparisons = 0

    matched_products = []
    threshold = initial_threshold
    output_folder_path = os.path.join(fr'/Users/g6-media/Deployment 2 latest/Scrapping Scripts/Output/temp\{output_folder}')
    os.makedirs(output_folder_path, exist_ok=True)

    flinn_file_path = os.path.join(r'/Users/g6-media/Deployment 2 latest/Scrapping Scripts/Output/Flinn_Products.csv')
    vwr_file_path = os.path.join(r'/Users/g6-media/Deployment 2 latest/Scrapping Scripts/Output/VWR_WARDS_Products.csv')

    flinn_csv = pd.read_csv(flinn_file_path)
    vwr_csv = pd.read_csv(vwr_file_path)
    options = Options()
    options.add_argument("--headless")

    result_queue = Queue()

    def worker(batch):
        local_results = []
        driver = webdriver.Chrome(options=options)
        for original_flinn_row, flinn_word_set in batch:
            result = process_flinn_product(original_flinn_row, flinn_word_set, vwr_products, threshold, driver, flinn_csv, vwr_csv)
            local_results.append(result)
        driver.quit()
        result_queue.put(local_results)

    while threshold >= 0:
        print(f"Matching products with threshold: {threshold:.2f}")
        output_file = os.path.join(output_folder_path, f"FlinnVsVWR_{threshold:.2f}.csv")

        with open(output_file, 'w', newline='', encoding='utf-8') as master_file:
            writer = csv.writer(master_file)
            writer.writerow(['Flinn_product_category', 'Flinn_product_sub_category', 'Flinn_product_id', 'Flinn_product_name',
                             'Flinn_product_quantity', 'Flinn_product_price', 'Flinn_product_url', 'Flinn_image_url',
                             'VWR_product_category', 'VWR_product_sub_category', 'VWR_product_id', 'VWR_product_name',
                             'VWR_product_quantity', 'VWR_product_price', 'VWR_product_url', 'VWR_image_url',
                             'VWR_Match_Score'])

            with concurrent.futures.ThreadPoolExecutor(max_workers=num_threads) as executor:
                for i in range(0, len(flinn_products), batch_size):
                    batch = flinn_products[i:i+batch_size]
                    executor.submit(worker, batch)

                executor.shutdown(wait=True)

            while not result_queue.empty():
                results = result_queue.get()
                for result in results:
                    original_flinn_row, best_match, best_match_score = result

                    flinn_colors = [color for color in color_names if re.search(rf'\b{color}\b', original_flinn_row['Flinn_product_name'], re.IGNORECASE)]
                    vwr_colors = [color for color in color_names if best_match and re.search(rf'\b{color}\b', best_match['VWR_product_name'], re.IGNORECASE)]

                    flinn_ml_mm = re.findall(r'\b\d+(\.\d+)?\s*(mL|mm)\b', original_flinn_row['Flinn_product_name'], re.IGNORECASE)
                    vwr_ml_mm = re.findall(r'\b\d+(\.\d+)?\s*(mL|mm)\b', best_match['VWR_product_name'], re.IGNORECASE) if best_match else []

                    if best_match_score >= threshold:
                        if set(flinn_colors) == set(vwr_colors) and set(flinn_ml_mm) == set(vwr_ml_mm):
                            writer.writerow([
                                original_flinn_row['Flinn_product_category'], original_flinn_row['Flinn_product_sub_category'],
                                original_flinn_row['Flinn_product_id'], original_flinn_row['Flinn_product_name'],
                                original_flinn_row['Flinn_product_quantity'], original_flinn_row['Flinn_product_price'],
                                original_flinn_row['Flinn_product_url'], original_flinn_row['Flinn_image_url'],
                                best_match['VWR_product_category'], best_match['VWR_product_sub_category'],
                                best_match['VWR_product_id'], best_match['VWR_product_name'],
                                best_match['VWR_product_quantity'], best_match['VWR_product_price'],
                                best_match['VWR_product_url'], best_match['VWR_image_url'], best_match_score
                            ])
                            matched_products.append((original_flinn_row, best_match, best_match_score))
                        elif set(flinn_colors) == set(vwr_colors):
                            writer.writerow([
                                original_flinn_row['Flinn_product_category'], original_flinn_row['Flinn_product_sub_category'],
                                original_flinn_row['Flinn_product_id'], original_flinn_row['Flinn_product_name'],
                                original_flinn_row['Flinn_product_quantity'], original_flinn_row['Flinn_product_price'],
                                original_flinn_row['Flinn_product_url'], original_flinn_row['Flinn_image_url'],
                                best_match['VWR_product_category'], best_match['VWR_product_sub_category'],
                                best_match['VWR_product_id'], best_match['VWR_product_name'],
                                best_match['VWR_product_quantity'], best_match['VWR_product_price'],
                                best_match['VWR_product_url'], best_match['VWR_image_url'], best_match_score
                            ])
                            matched_products.append((original_flinn_row, best_match, best_match_score))
                        else:
                            writer.writerow([
                                original_flinn_row['Flinn_product_category'], original_flinn_row['Flinn_product_sub_category'],
                                original_flinn_row['Flinn_product_id'], original_flinn_row['Flinn_product_name'],
                                original_flinn_row['Flinn_product_quantity'], original_flinn_row['Flinn_product_price'],
                                original_flinn_row['Flinn_product_url'], original_flinn_row['Flinn_image_url'],
                                best_match['VWR_product_category'], best_match['VWR_product_sub_category'],
                                best_match['VWR_product_id'], best_match['VWR_product_name'],
                                best_match['VWR_product_quantity'], best_match['VWR_product_price'],
                                best_match['VWR_product_url'], best_match['VWR_image_url'], best_match_score
                            ])
                            matched_products.append((original_flinn_row, best_match, best_match_score))
                    else:
                        writer.writerow([
                            original_flinn_row['Flinn_product_category'], original_flinn_row['Flinn_product_sub_category'],
                            original_flinn_row['Flinn_product_id'], original_flinn_row['Flinn_product_name'],
                            original_flinn_row['Flinn_product_quantity'], original_flinn_row['Flinn_product_price'],
                            original_flinn_row['Flinn_product_url'], original_flinn_row['Flinn_image_url'],
                            '', '', '', 'No good match found (Low match score)', '', '', '', '', 0
                        ])

                    total_comparisons += 1
                    if total_comparisons % 100 == 0:
                        elapsed_time = time.time() - start_time
                        print(f"Processed {total_comparisons} comparisons in {elapsed_time:.2f} seconds")
                        print(f"Current threshold: {threshold:.2f}")
                        print(f"Matches found: {len(matched_products)}")
                        print("---")

        threshold = round(threshold - threshold_decrement, 2)

    total_time = time.time() - start_time
    print(f"\nMatching completed:")
    print(f"Total comparisons: {total_comparisons}")
    print(f"Total time: {total_time:.2f} seconds")
    print(f"Comparisons per second: {total_comparisons / total_time:.2f}")
    print(f"Total matches found: {len(matched_products)}")

    return matched_products


flinn_file_path = os.path.join(r'/Users/g6-media/Deployment 2 latest/Scrapping Scripts/Output/Flinn_Products.csv')
vwr_file_path = os.path.join(r'/Users/g6-media/Deployment 2 latest/Scrapping Scripts/Output/VWR_WARDS_Products.csv')


with open(flinn_file_path, 'r', encoding='utf-8') as flinn_file, open(vwr_file_path, 'r', encoding='utf-8') as vwr_file:
    flinn_reader = csv.DictReader(flinn_file)
    vwr_reader = csv.DictReader(vwr_file)

    flinn_products = [(row, get_word_set(clean_text(row['Flinn_product_name']))) for row in flinn_reader]
    vwr_products = [(row, get_word_set(clean_text(row['VWR_product_name']))) for row in vwr_reader]


initial_threshold = 0.8
threshold_decrement = 0.01
output_folder = 'FlinnVsVWR'

output_files = match_products(flinn_products, vwr_products, initial_threshold, threshold_decrement, output_folder, batch_size=10000, num_threads=20)



output_csv_dir = r'/Users/g6-media/Deployment 2 latest/Scrapping Scripts/Output/temp/FlinnVsVWR/*.csv'
csv_files = glob.glob(output_csv_dir)
csv_files = [file for file in csv_files if not file.endswith('Matched_Products.csv')]
dfs = []
for csv_file in csv_files:
    df = pd.read_csv(csv_file)
    dfs.append(df)
merged_df = pd.concat(dfs, ignore_index=True)
merged_df.drop_duplicates(subset=['Flinn_product_name', 'Flinn_product_id'], keep='first', inplace=True)
merged_output_file = r'/Users/g6-media/Deployment 2 latest/Scrapping Scripts/Output/temp/FlinnVsVWR/Matched_Products.csv'
os.makedirs(os.path.dirname(merged_output_file), exist_ok=True)
merged_df.to_csv(merged_output_file, index=False)
print(f"Merged {len(csv_files)} CSV files into '{merged_output_file}'.")