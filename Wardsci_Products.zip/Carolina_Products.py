import json
from module_package import *
import random
from DrissionPage import ChromiumPage, ChromiumOptions
import concurrent.futures


def random_sleep(min_seconds=1, max_seconds=10):
    sleep_time = random.uniform(min_seconds, max_seconds)
    time.sleep(sleep_time)


def process_product(product_url, headers, product_category, product_sub_category):
    random_sleep(1, 10)
    product_request = get_soup(product_url, headers)
    if product_request is None:
        return None
    content = product_request.find('script', type='application/ld+json')
    replace_content = str(content).replace('<script type="application/ld+json">', '').replace('</script>', '')
    json_content = json.loads(replace_content)

    product_data = []
    for inner_json in json_content['offers']:
        try:
            product_price = f"$ {inner_json['price']}"
        except:
            product_price = ''

        try:
            product_url = inner_json['url']
        except:
            product_url = ''

        try:
            product_name = inner_json['name']
            if re.search('Pack of \\d+', str(product_name)):
                product_quantity = re.search('Pack of \\d+', str(product_name)).group().replace('Pack of', '').strip()
            else:
                product_quantity = 1
        except:
            product_name = json_content['name']
            product_quantity = '1'

        try:
            desc = inner_json['description']
            desc_soup = BeautifulSoup(desc, 'html.parser').text.strip()
            product_desc = BeautifulSoup(desc_soup, 'html.parser').text.strip()
        except:
            desc = json_content['description']
            desc_soup = BeautifulSoup(desc, 'html.parser').text.strip()
            product_desc = BeautifulSoup(desc_soup, 'html.parser').text.strip()

        try:
            image_url = inner_json['image']
        except:
            image_url = json_content['image']

        try:
            product_id = inner_json['sku']
        except:
            product_id = json_content['sku']
        print(product_url)
        print('current datetime------>', datetime.now())
        dictionary = {
            'Carolina_product_category': product_category,
            'Carolina_product_sub_category': product_sub_category,
            'Carolina_product_id': product_id,
            'Carolina_product_name': product_name,
            'Carolina_product_quantity': product_quantity,
            'Carolina_product_price': product_price,
            'Carolina_product_url': product_url,
            'Carolina_image_url': image_url,
            'Carolina_product_desc': product_desc
        }
        product_data.append(dictionary)

    return product_data


def process_page(page_link, headers, product_category, product_sub_category):
    random_sleep(1, 10)
    page_soup = get_soup(page_link, headers)
    if page_soup is None:
        return []

    inner_data = page_soup.find_all('div', class_='c-feature-product qv-model')
    product_urls = [f"{base_url}{single_data.find('a')['href']}" for single_data in inner_data]

    with concurrent.futures.ThreadPoolExecutor(max_workers=70) as executor:
        futures = [executor.submit(process_product, url, headers, product_category, product_sub_category) for url in
                   product_urls]
        results = [future.result() for future in concurrent.futures.as_completed(futures)]

    return [item for sublist in results if sublist is not None for item in sublist]


if __name__ == '__main__':
    timestamp = datetime.now().date().strftime('%Y%m%d')
    file_name = os.path.basename(__file__).rstrip('.py')
    url = 'https://www.carolina.com/'
    all_data = []
    base_url = 'https://www.carolina.com'
    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        # 'Accept-Encoding': 'gzip, deflate, br, zstd',
        'Accept-Language': 'en-US,en;q=0.9',
        'Cache-Control': 'max-age=0',
        'Connection': 'keep-alive',
        'Cookie': 'sib_cuid=f9bfa3f7-bb99-4d53-9b93-e31d2d79b617; _gcl_au=1.1.143815260.1713870676; _fbp=fb.1.1713870676303.1039358499; userty.core.p.89cc84=__2VySWQiOiIzOTMxY2I0YzcyNmZhMTcyMjhjY2JiYzkzZWZkOWEzZiJ9eyJ1c; hubspotutk=d1ce3404a88b213b8f3d1c5303da6434; lhnContact=0e841d9b-aa89-4142-bcd9-0c6a7f768fe4-24984-NXFAoQd; BVBRANDID=64921e2f-2bd3-4794-a737-3ebb4039539b; acceptCookieTermsCookie=; wp36423="WZXVWDDDDDDCTALMVZA-WZWT-XCVY-ITKC-ATBCHIBBUYIJDgNssDJHkhspgH_JhtDD"; _ga_QTJ7CYYKHD=GS1.1.1714720419.1.1.1714720423.0.0.0; serverRoute=PRXYm1AkGl3b0NvpJxQXRUAe9D8rIAO8ThMahOot1vk7-PtxNsEL!2107698643!1721620975652-app4; _gid=GA1.2.1441900401.1721620987; __hssrc=1; lhnStorageType=cookie; lhnRefresh=86336e7a-6d9f-498f-8fb2-44631a03505f; lhnJWT=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOiJ2aXNpdG9yIiwiZG9tYWluIjoiIiwiZXhwIjoxNzIxNzA3MzkyLCJpYXQiOjE3MjE2MjA5OTIsImlzcyI6eyJhcHAiOiJqc19zZGsiLCJjbGllbnQiOjI0OTg0LCJjbGllbnRfbGV2ZWwiOiJiYXNpYyIsImxobnhfZmVhdHVyZXMiOltdLCJ2aXNpdG9yX3RyYWNraW5nIjp0cnVlfSwianRpIjoiMGU4NDFkOWItYWE4OS00MTQyLWJjZDktMGM2YTdmNzY4ZmU0IiwicmVzb3VyY2UiOnsiaWQiOiIwZTg0MWQ5Yi1hYTg5LTQxNDItYmNkOS0wYzZhN2Y3NjhmZTQtMjQ5ODQtTlhGQW9RZCIsInR5cGUiOiJFbGl4aXIuTGhuRGIuTW9kZWwuQ29yZS5WaXNpdG9yIn19.E-18_dm9vduF0Brx7qKVZUeY_nbik-cunKLm0PCOcsw; wisepops_visits=%5B%222024-07-22T06%3A11%3A01.915Z%22%2C%222024-07-22T06%3A10%3A44.041Z%22%2C%222024-07-22T06%3A07%3A02.823Z%22%2C%222024-07-22T05%3A57%3A29.931Z%22%2C%222024-07-22T04%3A03%3A11.209Z%22%2C%222024-07-22T04%3A03%3A06.678Z%22%2C%222024-07-17T06%3A49%3A20.330Z%22%2C%222024-07-15T11%3A30%3A31.919Z%22%2C%222024-07-15T11%3A22%3A27.264Z%22%2C%222024-07-11T07%3A13%3A50.383Z%22%5D; SSID=CQD_xh1GAAAAAABQlydm2gKDDFCXJ2ZZAAAAAAAAAAAAIwmeZgDSFc7HAAPFchsAUJcnZk8AgjEBAWx0JgAjCZ5mAQCNNwED_xUnAN_Ic2YmAJNHAQOGjSgAcAaVZgUAHisBA2PUJQBQlydmTwA; SSSC=695.G7361018486023455450.89|51150.1798853:76574.2479203:78210.2520172:79757.2561535:83859.2657670; SSRT=IwmeZgADAA; SSOD=AAFKAAAASAAxWEYACgIAAFCXJ2YjCZ5mAQCM6TgACgAAAANMK2Y2LXxmAABVWzQAAgAAAJCONGa5jjRmAACoqDcAAgAAAJCONGa5jjRmAAAAAA; CBSESSIONID=dQDZU7OCQ1MP7nttswpi6l22dPqRvyaKEndx5QpgbNhaKTuJgDEu!2107698643; _gat_UA-159461-1=1; _ga_2J2J1CBM0T=GS1.1.1721633063.115.0.1721633063.60.0.0; wisepops=%7B%22popups%22%3A%7B%22472246%22%3A%7B%22dc%22%3A1%2C%22d%22%3A1719389190833%7D%2C%22492430%22%3A%7B%22dc%22%3A1%2C%22d%22%3A1716199760335%2C%22cl%22%3A1%7D%2C%22495677%22%3A%7B%22dc%22%3A1%2C%22d%22%3A1717998220810%2C%22cl%22%3A1%7D%7D%2C%22sub%22%3A0%2C%22ucrn%22%3A53%2C%22cid%22%3A%2248011%22%2C%22v%22%3A4%2C%22bandit%22%3A%7B%22recos%22%3A%7B%7D%7D%7D; _ga=GA1.2.259678292.1713870676; _hp2_id.324705833=%7B%22userId%22%3A%221374166632732052%22%2C%22pageviewId%22%3A%223053154268530308%22%2C%22sessionId%22%3A%222505551738946815%22%2C%22identity%22%3Anull%2C%22trackerVersion%22%3A%224.0%22%7D; _uetsid=4d26722047df11efa2fe97fa802c13ec; _uetvid=3409c3a0016211efb8692f184a9b3ea5; datadome=PmQbJ_dnithzqWlCzzAS4dLhNVWtrJHuI3mHdAGXriHHYdvJyM3vk4ob7mJ7P8VsoyUXVQZK_P9vCWtxe6WqvKkhFL5bW4ZxQvsXz2j0ma656c4tx6ML65HrHyYIyrE1; wisepops_visitor=%7B%22JFEHQjxXN3%22%3A%225e155381-f6fa-4d54-9b1c-28e73243d7bf%22%7D; wisepops_session=%7B%22arrivalOnSite%22%3A%222024-07-22T06%3A11%3A01.915Z%22%2C%22mtime%22%3A1721633063708%2C%22pageviews%22%3A9%2C%22popups%22%3A%7B%7D%2C%22bars%22%3A%7B%7D%2C%22sticky%22%3A%7B%7D%2C%22countdowns%22%3A%7B%7D%2C%22src%22%3Anull%2C%22utm%22%3A%7B%7D%2C%22testIp%22%3Anull%7D; __hstc=5999596.d1ce3404a88b213b8f3d1c5303da6434.1713870678828.1721628399547.1721633065073.83; __hssc=5999596.1.1721633065073; _hp2_ses_props.324705833=%7B%22r%22%3A%22https%3A%2F%2Fwww.carolina.com%2F%22%2C%22ts%22%3A1721633063473%2C%22d%22%3A%22www.carolina.com%22%2C%22h%22%3A%22%2F%22%7D; userty.core.s.89cc84=__WQiOiI1ZWZkNTU4ZTRhNTZmMGUxMjFkNDVmZTczZDQ1ZWY2ZiIsInN0IjoxNzIxNjMzMDY1MTEzLCJyZWFkeSI6dHJ1ZSwid3MiOiJ7XCJ3XCI6MTUzNixcImhcIjo3MzB9Iiwic2UiOjE3MjE2MzQ4NzEyMTUsInB2IjoxfQ==eyJza',
        'Host': 'www.carolina.com',
        'Referer': 'https://www.carolina.com/',
        'Sec-Ch-Device-Memory': '8',
        'Sec-Ch-Ua': '"Not/A)Brand";v="8", "Chromium";v="126", "Google Chrome";v="126"',
        'Sec-Ch-Ua-Arch': '"x86"',
        'Sec-Ch-Ua-Full-Version-List': '"Not/A)Brand";v="8.0.0.0", "Chromium";v="126.0.6478.128", "Google Chrome";v="126.0.6478.128"',
        'Sec-Ch-Ua-Mobile': '?0',
        'Sec-Ch-Ua-Model': '""',
        'Sec-Ch-Ua-Platform': '"Windows"',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-User': '?1',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
    }
    soup = get_soup(url, headers)
    content = soup.find('li', class_='nav-item c-nav-menu-link').find_all('li', class_='row c-nav-menu-l1')
    for single_content in content:
        inner_content = single_content.find('div', class_='c-nav-menu-subnav col-12 col-lg-7')
        product_category = inner_content.find('h3', class_='d-none d-lg-block').text.strip()
        if inner_content.find('ul', class_='row'):
            all_urls = inner_content.find('ul', class_='row').find_all('li')
            for single_url in all_urls:
                product_sub_name = single_url.a.text.strip()
                main_url = f"{base_url}{single_url.a['href']}"
                print(f'main_url -----------> {main_url}')
                random_sleep(1, 10)
                inner_request = get_soup(main_url, headers)
                if inner_request is None:
                    continue
                if inner_request.find('div', class_='row px-1'):
                    inner_data = inner_request.find('div', class_='row px-1').find_all('a', class_='c-category-list')
                    for single_data in inner_data:
                        inner_url = f'{base_url}{single_data["href"]}'
                        inner_category = strip_it(single_data.find('h3', class_='c-category-title').text.strip())
                        sub_category = single_url.a.text.strip()
                        product_sub = f'{sub_category}-{inner_category}'
                        random_sleep(1, 10)
                        other_request = get_soup(inner_url, headers)
                        if other_request.find('div', class_='row px-1'):
                            inner_data = other_request.find('div', class_='row px-1').find_all('a', class_='c-category-list')
                            for single_datas in inner_data:
                                inner_process_url = f'{base_url}{single_datas["href"]}'
                                inner_categories = strip_it(single_datas.find('h3', class_='c-category-title').text.strip())
                                product_sub_category = f'{product_sub}-{inner_categories}'
                                inner_process_request = get_soup(inner_process_url, headers)
                                '''GET PAGINATION'''
                                if inner_request.find('ul',
                                                      class_='c-pagination pagination justify-content-start pagination-lg'):
                                    total_page = int(inner_request.find('ul',
                                                                        class_='c-pagination pagination justify-content-start pagination-lg').find_all(
                                        'li')[-2].text.strip())

                                    with concurrent.futures.ThreadPoolExecutor(max_workers=70) as executor:
                                        page_links = [
                                            f'{main_url}?Nf=product.cbsLowPrice%7CGT+0.0%7C%7Cproduct.startDate%7CLTEQ+1.71504E12%7C%7Cproduct.startDate%7CLTEQ+1.71504E12&No={i * 60}&Nr=&'
                                            for i in range(total_page)]
                                        futures = [executor.submit(process_page, link, headers, product_category,
                                                                   product_sub_name) for link in page_links]
                                        results = [future.result() for future in
                                                   concurrent.futures.as_completed(futures)]

                                    all_data.extend([item for sublist in results for item in sublist])
                                else:
                                    all_data.extend(process_page(main_url, headers, product_category, product_sub_name))

                                articles_df = pd.DataFrame(all_data)
                                articles_df.drop_duplicates(subset=['Carolina_product_id', 'Carolina_product_name'],
                                                            keep='first', inplace=True)
                                output_dir = r'D:/svc_webscrape/Deployment 2/Scrapping Scripts/Output'
                                if not os.path.exists(output_dir):
                                    os.makedirs(output_dir)
                                file_path = os.path.join(output_dir, f'{file_name}.csv')
                                articles_df.to_csv(file_path, index=False)
                        else:
                            product_sub_category = product_sub
                            '''GET PAGINATION'''
                            if inner_request.find('ul',
                                                  class_='c-pagination pagination justify-content-start pagination-lg'):
                                total_page = int(inner_request.find('ul',
                                                                    class_='c-pagination pagination justify-content-start pagination-lg').find_all(
                                    'li')[-2].text.strip())

                                with concurrent.futures.ThreadPoolExecutor(max_workers=70) as executor:
                                    page_links = [
                                        f'{main_url}?Nf=product.cbsLowPrice%7CGT+0.0%7C%7Cproduct.startDate%7CLTEQ+1.71504E12%7C%7Cproduct.startDate%7CLTEQ+1.71504E12&No={i * 60}&Nr=&'
                                        for i in range(total_page)]
                                    futures = [
                                        executor.submit(process_page, link, headers, product_category, product_sub_name)
                                        for link in page_links]
                                    results = [future.result() for future in concurrent.futures.as_completed(futures)]

                                all_data.extend([item for sublist in results for item in sublist])
                            else:
                                all_data.extend(process_page(main_url, headers, product_category, product_sub_name))

                            articles_df = pd.DataFrame(all_data)
                            articles_df.drop_duplicates(subset=['Carolina_product_id', 'Carolina_product_name'],
                                                        keep='first', inplace=True)
                            output_dir = r'D:/svc_webscrape/Deployment 2/Scrapping Scripts/Output'
                            if not os.path.exists(output_dir):
                                os.makedirs(output_dir)
                            file_path = os.path.join(output_dir, f'{file_name}.csv')
                            articles_df.to_csv(file_path, index=False)
                else:
                    product_sub_category = product_sub_name
                    '''GET PAGINATION'''
                    if inner_request.find('ul', class_='c-pagination pagination justify-content-start pagination-lg'):
                        total_page = int(inner_request.find('ul',
                                                            class_='c-pagination pagination justify-content-start pagination-lg').find_all(
                            'li')[-2].text.strip())

                        with concurrent.futures.ThreadPoolExecutor(max_workers=70) as executor:
                            page_links = [
                                f'{main_url}?Nf=product.cbsLowPrice%7CGT+0.0%7C%7Cproduct.startDate%7CLTEQ+1.71504E12%7C%7Cproduct.startDate%7CLTEQ+1.71504E12&No={i * 60}&Nr=&'
                                for i in range(total_page)]
                            futures = [executor.submit(process_page, link, headers, product_category, product_sub_name)
                                       for link in page_links]
                            results = [future.result() for future in concurrent.futures.as_completed(futures)]

                        all_data.extend([item for sublist in results for item in sublist])
                    else:
                        all_data.extend(process_page(main_url, headers, product_category, product_sub_name))

                    articles_df = pd.DataFrame(all_data)
                    articles_df.drop_duplicates(subset=['Carolina_product_id', 'Carolina_product_name'], keep='first',
                                                inplace=True)
                    output_dir = r'D:/svc_webscrape/Deployment 2/Scrapping Scripts/Output'
                    if not os.path.exists(output_dir):
                        os.makedirs(output_dir)
                    file_path = os.path.join(output_dir, f'{file_name}.csv')
                    articles_df.to_csv(file_path, index=False)